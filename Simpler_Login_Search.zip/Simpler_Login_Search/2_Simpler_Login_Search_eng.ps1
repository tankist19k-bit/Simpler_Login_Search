# 2_Simpler_Login_Search_eng.ps1
# Windows PowerShell 5.1
# Supports JSON and CSV password exports.

$ErrorActionPreference = "Stop"

$Folder = Split-Path -Parent $MyInvocation.MyCommand.Path
$ResultFile = Join-Path $Folder "2_RESULTS.txt"

function Add-Account {
    param(
        [hashtable]$Map,
        [string]$Password,
        [string]$Name,
        [string]$Username,
        [string]$URI
    )

    if ([string]::IsNullOrEmpty($Password)) { return }

    if (-not $Map.ContainsKey($Password)) {
        $Map[$Password] = @()
    }

    $Map[$Password] += [PSCustomObject]@{
        Name = $Name
        Username = $Username
        URI = $URI
    }
}

function Get-TextValue {
    param(
        [object]$Object,
        [string[]]$Names
    )

    if ($null -eq $Object) { return "" }

    foreach ($Name in $Names) {
        $Property = $Object.PSObject.Properties |
            Where-Object { $_.Name -ieq $Name } |
            Select-Object -First 1

        if ($null -ne $Property) {
            $Value = $Property.Value
            if ($null -ne $Value -and
                $Value -isnot [System.Array] -and
                $Value -isnot [PSCustomObject]) {
                $Text = [string]$Value
                if ($Text.Length -gt 0) { return $Text }
            }
        }
    }

    return ""
}

function Get-LoginUri {
    param([object]$Login)

    if ($null -eq $Login) { return "" }
    if ($null -eq $Login.uris) { return "" }

    foreach ($UriItem in @($Login.uris)) {
        if ($null -eq $UriItem) { continue }

        if ($UriItem.uri) {
            return [string]$UriItem.uri
        }

        if ($UriItem.url) {
            return [string]$UriItem.url
        }
    }

    return ""
}

function Import-JsonExport {
    param(
        [string]$Path,
        [hashtable]$Map
    )

    $Root = Get-Content -Raw -Path $Path | ConvertFrom-Json

    if ($null -ne $Root.items) {
        $Items = @($Root.items)
    }
    elseif ($null -ne $Root.logins) {
        $Items = @($Root.logins)
    }
    elseif ($null -ne $Root.passwords) {
        $Items = @($Root.passwords)
    }
    elseif ($Root -is [System.Array]) {
        $Items = @($Root)
    }
    else {
        $Items = @($Root)
    }

    foreach ($Item in $Items) {
        $Name = Get-TextValue $Item @("name","title","site","service","label")
        $Username = Get-TextValue $Item @("username","user","login","email","emailAddress")
        $Password = Get-TextValue $Item @("password","passwd","pass","pwd")
        $URI = Get-TextValue $Item @("url","uri","website","login_uri")

        if ($null -ne $Item.login) {
            if (-not $Username) {
                $Username = Get-TextValue $Item.login @("username","user","login","email","emailAddress")
            }

            if (-not $Password) {
                $Password = Get-TextValue $Item.login @("password","passwd","pass","pwd")
            }

            if (-not $URI) {
                $URI = Get-LoginUri $Item.login
            }
        }

        Add-Account -Map $Map -Password $Password -Name $Name -Username $Username -URI $URI
    }
}

function Find-CsvColumn {
    param(
        [object[]]$Rows,
        [string[]]$Names
    )

    if ($Rows.Count -eq 0) { return $null }

    $Headers = @($Rows[0].PSObject.Properties.Name)

    foreach ($Wanted in $Names) {
        foreach ($Header in $Headers) {
            if ($Header.Trim() -ieq $Wanted) {
                return $Header
            }
        }
    }

    foreach ($Wanted in $Names) {
        foreach ($Header in $Headers) {
            if ($Header.Trim().ToLowerInvariant().Contains($Wanted.ToLowerInvariant())) {
                return $Header
            }
        }
    }

    return $null
}

function Import-CsvExport {
    param(
        [string]$Path,
        [hashtable]$Map
    )

    $Rows = @(Import-Csv -Path $Path)

    if ($Rows.Count -eq 0) {
        throw "CSV is empty or could not be read."
    }

    $PasswordColumn = Find-CsvColumn $Rows @(
        "password","passwd","pass","pwd"
    )

    if (-not $PasswordColumn) {
        throw "No password column was found in this CSV."
    }

    $UsernameColumn = Find-CsvColumn $Rows @(
        "username","user","login","email","emailaddress"
    )

    $NameColumn = Find-CsvColumn $Rows @(
        "name","title","site","website","service","label"
    )

    $UriColumn = Find-CsvColumn $Rows @(
        "url","uri","website","login_uri"
    )

    foreach ($Row in $Rows) {
        $Password = [string]$Row.PSObject.Properties[$PasswordColumn].Value
        $Username = ""
        $Name = ""
        $URI = ""

        if ($UsernameColumn) {
            $Username = [string]$Row.PSObject.Properties[$UsernameColumn].Value
        }

        if ($NameColumn) {
            $Name = [string]$Row.PSObject.Properties[$NameColumn].Value
        }

        if ($UriColumn) {
            $URI = [string]$Row.PSObject.Properties[$UriColumn].Value
        }

        Add-Account -Map $Map -Password $Password -Name $Name -Username $Username -URI $URI
    }
}

$Files = @(
    Get-ChildItem -Path $Folder -File |
    Where-Object {
        ($_.Extension -ieq ".json" -or $_.Extension -ieq ".csv") -and
        $_.Name -notlike "2_RESULTS*"
    }
)

Clear-Host
Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "         SIMPLER LOGIN SEARCH" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

if ($Files.Count -eq 0) {
    Write-Host "No JSON or CSV files were found in this folder." -ForegroundColor Red
    Write-Host ""
    Read-Host "Press Enter to exit"
    exit
}

Write-Host "Available export files:" -ForegroundColor Yellow
Write-Host ""

for ($i = 0; $i -lt $Files.Count; $i++) {
    Write-Host ("  [{0}] {1}" -f ($i + 1), $Files[$i].Name)
}

Write-Host ""
Write-Host "  [0] Automatically select the newest file" -ForegroundColor DarkGray
Write-Host ""

$Choice = Read-Host "Which export file do you want to open?"

if ([string]::IsNullOrWhiteSpace($Choice) -or $Choice -eq "0") {
    $Selected = $Files | Sort-Object LastWriteTime -Descending | Select-Object -First 1
}
else {
    $Number = 0

    if (-not [int]::TryParse($Choice, [ref]$Number)) {
        Write-Host ""
        Write-Host "Invalid selection." -ForegroundColor Red
        Read-Host "Press Enter to exit"
        exit
    }

    $Index = $Number - 1

    if ($Index -lt 0 -or $Index -ge $Files.Count) {
        Write-Host ""
        Write-Host "Invalid selection." -ForegroundColor Red
        Read-Host "Press Enter to exit"
        exit
    }

    $Selected = $Files[$Index]
}

Clear-Host
Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "         SIMPLER LOGIN SEARCH" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host ("Selected file: {0}" -f $Selected.Name) -ForegroundColor Green
Write-Host ""

$Passwords = @{}

try {
    if ($Selected.Extension -ieq ".json") {
        Import-JsonExport -Path $Selected.FullName -Map $Passwords
    }
    else {
        Import-CsvExport -Path $Selected.FullName -Map $Passwords
    }
}
catch {
    Write-Host ("File read error: {0}" -f $_.Exception.Message) -ForegroundColor Red
    Write-Host ""
    Read-Host "Press Enter to exit"
    exit
}

Write-Host ("Unique passwords found: {0}" -f $Passwords.Count) -ForegroundColor Cyan
Write-Host ""
Write-Host "Checking through Have I Been Pwned..." -ForegroundColor Yellow
Write-Host ""

@"
Simpler Login Search
!!!ATTENTION: DELETE THE JSON/CSV EXPORT FILE WITH PASSWORDS AFTER THE CHECK!!!

Search performed through the available website "Have I Been Pwned"
https://haveibeenpwned.com/Passwords
Date: $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")
File: $($Selected.Name)

========================================
RESULTS
========================================

"@ | Set-Content -Path $ResultFile -Encoding UTF8

$FoundAny = $false
$FoundPasswords = 0
$Checked = 0
$Errors = 0

foreach ($Password in $Passwords.Keys) {
    $Checked++

    Write-Progress `
        -Activity "Checking passwords through HIBP" `
        -Status "$Checked / $($Passwords.Count)" `
        -PercentComplete (($Checked / $Passwords.Count) * 100)

    $Bytes = [System.Text.Encoding]::UTF8.GetBytes($Password)
    $Sha1 = [System.Security.Cryptography.SHA1]::Create()
    $HashBytes = $Sha1.ComputeHash($Bytes)
    $Hash = -join ($HashBytes | ForEach-Object { $_.ToString("X2") })

    $Prefix = $Hash.Substring(0,5)
    $Suffix = $Hash.Substring(5)

    try {
        $Response = Invoke-RestMethod `
            -Uri ("https://api.pwnedpasswords.com/range/" + $Prefix) `
            -Headers @{"Add-Padding"="true"} `
            -Method Get `
            -ErrorAction Stop

        foreach ($Line in ($Response -split "`r?`n")) {
            if ([string]::IsNullOrWhiteSpace($Line)) { continue }

            $Parts = $Line -split ":"
            if ($Parts.Count -ne 2) { continue }

            $RemoteSuffix = $Parts[0].Trim().ToUpperInvariant()
            $Count = $Parts[1].Trim()

            if ($RemoteSuffix -eq $Suffix) {
                $FoundAny = $true
                $FoundPasswords++

                Add-Content -Path $ResultFile -Encoding UTF8 -Value "========================================"
                Add-Content -Path $ResultFile -Encoding UTF8 -Value ("COMPROMISED PASSWORD #{0}" -f $FoundPasswords)
                Add-Content -Path $ResultFile -Encoding UTF8 -Value "========================================"
                Add-Content -Path $ResultFile -Encoding UTF8 -Value ("Password: {0}" -f $Password)
                Add-Content -Path $ResultFile -Encoding UTF8 -Value ("Times seen by HIBP: {0}" -f $Count)
                Add-Content -Path $ResultFile -Encoding UTF8 -Value ""
                Add-Content -Path $ResultFile -Encoding UTF8 -Value "Used in:"

                foreach ($Account in $Passwords[$Password]) {
                    Add-Content -Path $ResultFile -Encoding UTF8 -Value "----------------------------------------"
                    Add-Content -Path $ResultFile -Encoding UTF8 -Value ("Site:     {0}" -f $Account.Name)
                    Add-Content -Path $ResultFile -Encoding UTF8 -Value ("Username: {0}" -f $Account.Username)
                    Add-Content -Path $ResultFile -Encoding UTF8 -Value ("URL:      {0}" -f $Account.URI)
                }

                Add-Content -Path $ResultFile -Encoding UTF8 -Value ""
                Add-Content -Path $ResultFile -Encoding UTF8 -Value ""

                Write-Host "COMPROMISED PASSWORD FOUND" -ForegroundColor Red
                break
            }
        }
    }
    catch {
        $Errors++
    }
}

Write-Progress -Activity "Checking passwords through HIBP" -Completed

Add-Content -Path $ResultFile -Encoding UTF8 -Value "========================================"
Add-Content -Path $ResultFile -Encoding UTF8 -Value "SUMMARY"
Add-Content -Path $ResultFile -Encoding UTF8 -Value "========================================"
Add-Content -Path $ResultFile -Encoding UTF8 -Value ("Unique passwords checked: {0}" -f $Passwords.Count)
Add-Content -Path $ResultFile -Encoding UTF8 -Value ("Compromised passwords found: {0}" -f $FoundPasswords)
Add-Content -Path $ResultFile -Encoding UTF8 -Value ("Errors during check: {0}" -f $Errors)

Clear-Host
Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "         SIMPLER LOGIN SEARCH" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host ("Unique passwords checked: {0}" -f $Passwords.Count)

if ($FoundAny) {
    Write-Host ("Compromised passwords found: {0}" -f $FoundPasswords) -ForegroundColor Red
}
else {
    Write-Host "No compromised passwords found." -ForegroundColor Green
}

if ($Errors -gt 0) {
    Write-Host ("Errors during check: {0}" -f $Errors) -ForegroundColor Yellow
}

Write-Host ""
Write-Host ("Result saved to: {0}" -f $ResultFile) -ForegroundColor Green
Write-Host ""
Write-Host "!!! AFTER THE CHECK, DELETE THE EXPORT FILE WITH PASSWORDS !!!" -ForegroundColor Yellow
Write-Host ""
Read-Host "Press Enter to exit"
