@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -NoLogo -File "%~dp01_Simpler_Login_Search.ps1"
endlocal
