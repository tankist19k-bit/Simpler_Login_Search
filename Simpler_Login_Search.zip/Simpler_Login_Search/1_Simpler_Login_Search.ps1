# Simpler Login Search
# Windows PowerShell 5.1
# JSON + CSV password export checker
$ErrorActionPreference = "Stop"
try { [Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false) } catch {}

function RU([string]$B64) { [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($B64)) }

$R_title = "U2ltcGxlciBMb2dpbiBTZWFyY2g="
$R_files = "0JTQvtGB0YLRg9C/0L3Ri9C1INGE0LDQudC70Ysg0Y3QutGB0L/QvtGA0YLQsDo="
$R_newest = "0JDQstGC0L7QvNCw0YLQuNGH0LXRgdC60Lgg0LLRi9Cx0YDQsNGC0Ywg0YHQsNC80YvQuSDQvdC+0LLRi9C5INGE0LDQudC7"
$R_prompt = "0JrQsNC60L7QuSDRhNCw0LnQuyDRjdC60YHQv9C+0YDRgtCwINCy0Ysg0YXQvtGC0LjRgtC1INC+0YLQutGA0YvRgtGMPw=="
$R_bad = "0J3QtdCy0LXRgNC90YvQuSDQstGL0LHQvtGALg=="
$R_selected = "0JLRi9Cx0YDQsNC9INGE0LDQudC7OiB7MH0="
$R_loading = "0JfQsNCz0YDRg9C30LrQsCDQv9Cw0YDQvtC70LXQuS4uLg=="
$R_unique = "0KPQvdC40LrQsNC70YzQvdGL0YUg0L/QsNGA0L7Qu9C10Lk6IHswfQ=="
$R_checking = "0J/RgNC+0LLQtdGA0LrQsCDRh9C10YDQtdC3IEhhdmUgSSBCZWVuIFB3bmVkLi4u"
$R_no_files = "0JIg0Y3RgtC+0Lkg0L/QsNC/0LrQtSDQvdC10YIg0YTQsNC50LvQvtCyIEpTT04g0LjQu9C4IENTVi4="
$R_read_error = "0J7RiNC40LHQutCwINGH0YLQtdC90LjRjyDRhNCw0LnQu9CwOiB7MH0="
$R_csv_empty = "Q1NWINC/0YPRgdGCINC40LvQuCDQvdC1INGD0LTQsNC70L7RgdGMINC10LPQviDQv9GA0L7Rh9C40YLQsNGC0Ywu"
$R_no_pass_col = "0JIgQ1NWINC90LUg0L3QsNC50LTQtdC9INGB0YLQvtC70LHQtdGGINGBINC/0LDRgNC+0LvQtdC8Lg=="
$R_warning = "ISEh0JLQndCY0JzQkNCd0JjQlSDQo9CU0JDQm9CYIEpTT04vQ1NWINCk0JDQmdCbINChINCf0JDQoNCe0JvQr9Cc0Jgg0JTQm9CvINCR0JXQl9Ce0J/QkNCh0J3QntCh0KLQmCEhIQ=="
$R_search = "0J/QvtC40YHQuiDQv9GA0L7QuNC30LLQtdC00ZHQvSDRh9C10YDQtdC3INC00L7RgdGC0YPQv9C90YvQuSDRgdCw0LnRgiAiSGF2ZSBJIEJlZW4gUHduZWQi"
$R_date = "0JTQsNGC0LA6IHswfQ=="
$R_file = "0KTQsNC50Ls6IHswfQ=="
$R_results = "0KDQldCX0KPQm9Cs0KLQkNCi0Ks="
$R_comp = "0KHQmtCe0JzQn9Cg0J7QnNCV0KLQmNCg0J7QktCQ0J3QndCr0Jkg0J/QkNCg0J7Qm9CsIOKElnswfQ=="
$R_password = "0J/QsNGA0L7Qu9GMOiB7MH0="
$R_count = "0JrQvtC70LjRh9C10YHRgtCy0L4g0L/QvtGP0LLQu9C10L3QuNC5INCyIEhJQlA6IHswfQ=="
$R_used = "0JjRgdC/0L7Qu9GM0LfRg9C10YLRgdGPINCyOg=="
$R_site = "0KHQsNC50YI6ICAgICB7MH0="
$R_login = "0JvQvtCz0LjQvTogICAgezB9"
$R_url = "VVJMOiAgICAgIHswfQ=="
$R_summary = "0JjQotCe0JM="
$R_checked = "0J/RgNC+0LLQtdGA0LXQvdC+INGD0L3QuNC60LDQu9GM0L3Ri9GFINC/0LDRgNC+0LvQtdC5OiB7MH0="
$R_found = "0KHQutC+0LzQv9GA0L7QvNC10YLQuNGA0L7QstCw0L3QvdGL0YUg0L/QsNGA0L7Qu9C10Lk6IHswfQ=="
$R_errors = "0J7RiNC40LHQvtC6INC/0YDQvtCy0LXRgNC60Lg6IHswfQ=="
$R_saved = "0KDQtdC30YPQu9GM0YLQsNGCINGB0L7RhdGA0LDQvdGR0L06IHswfQ=="
$R_none = "0KHQutC+0LzQv9GA0L7QvNC10YLQuNGA0L7QstCw0L3QvdGL0YUg0L/QsNGA0L7Qu9C10Lkg0L3QtSDQvdCw0LnQtNC10L3Qvi4="
$R_delete = "ISEhINCf0J7QodCb0JUg0J/QoNCe0JLQldCg0JrQmCDQo9CU0JDQm9CYINCk0JDQmdCbINCt0JrQodCf0J7QoNCi0JAg0KEg0J/QkNCg0J7Qm9Cv0JzQmCAhISE="
$R_exit = "0J3QsNC20LzQuNGC0LUgRW50ZXIg0LTQu9GPINCy0YvRhdC+0LTQsA=="
$R_found_console = "0J3QkNCZ0JTQldCdINCh0JrQntCc0J/QoNCe0JzQldCi0JjQoNCe0JLQkNCd0J3Qq9CZINCf0JDQoNCe0JvQrA=="
$Folder = Split-Path -Parent $MyInvocation.MyCommand.Path
$ResultFile = Join-Path $Folder "2_RESULTS.txt"

function Add-Account { param([hashtable]$Map,[string]$Password,[string]$Name,[string]$Username,[string]$URI)
  if ([string]::IsNullOrEmpty($Password)) { return }
  if (-not $Map.ContainsKey($Password)) { $Map[$Password] = @() }
  $Map[$Password] += [PSCustomObject]@{Name=$Name;Username=$Username;URI=$URI}
}

function Get-Scalar { param([object]$Object,[string[]]$Names)
  if ($null -eq $Object) { return "" }
  foreach ($n in $Names) {
    $p = $Object.PSObject.Properties | Where-Object { $_.Name.Trim().ToLowerInvariant() -eq $n.ToLowerInvariant() } | Select-Object -First 1
    if ($null -ne $p -and $null -ne $p.Value -and $p.Value -isnot [Array] -and $p.Value -isnot [PSCustomObject]) { $s=[string]$p.Value; if ($s) { return $s } }
  }
  foreach ($n in $Names) {
    $p = $Object.PSObject.Properties | Where-Object { $_.Name.Trim().ToLowerInvariant().Contains($n.ToLowerInvariant()) } | Select-Object -First 1
    if ($null -ne $p -and $null -ne $p.Value -and $p.Value -isnot [Array] -and $p.Value -isnot [PSCustomObject]) { $s=[string]$p.Value; if ($s) { return $s } }
  }
  return ""
}

function Get-URI { param([object]$Login)
  if ($null -eq $Login -or $null -eq $Login.uris) { return "" }
  foreach ($u in @($Login.uris)) {
    if ($null -ne $u -and $u.uri) { return [string]$u.uri }
    if ($null -ne $u -and $u.url) { return [string]$u.url }
  }
  return ""
}

function Import-JsonExport { param([string]$Path,[hashtable]$Map)
  $root=Get-Content -Raw -Path $Path | ConvertFrom-Json
  if ($null -ne $root.items) { $items=@($root.items) } elseif ($null -ne $root.logins) { $items=@($root.logins) } elseif ($null -ne $root.passwords) { $items=@($root.passwords) } elseif ($root -is [Array]) { $items=@($root) } else { $items=@($root) }
  foreach ($item in $items) {
    $name=Get-Scalar $item @("name","title","site","service","label")
    $user=Get-Scalar $item @("username","user","login","email","emailaddress")
    $pass=Get-Scalar $item @("password","passwd","pass","pwd")
    $uri=Get-Scalar $item @("url","uri","website","login_uri")
    if ($null -ne $item.login) {
      if (-not $user) { $user=Get-Scalar $item.login @("username","user","login","email","emailaddress") }
      if (-not $pass) { $pass=Get-Scalar $item.login @("password","passwd","pass","pwd") }
      if (-not $uri) { $uri=Get-URI $item.login }
    }
    Add-Account $Map $pass $name $user $uri
  }
}

function Find-CsvColumn { param([object[]]$Rows,[string[]]$Candidates)
  if ($Rows.Count -eq 0) { return $null }
  $headers=@($Rows[0].PSObject.Properties.Name)
  foreach ($c in $Candidates) { foreach ($h in $headers) { if ($h.Trim().ToLowerInvariant() -eq $c.ToLowerInvariant()) { return $h } } }
  foreach ($c in $Candidates) { foreach ($h in $headers) { if ($h.Trim().ToLowerInvariant().Contains($c.ToLowerInvariant())) { return $h } } }
  return $null
}

function Import-CsvExport { param([string]$Path,[hashtable]$Map)
  $rows=@(Import-Csv -Path $Path)
  if ($rows.Count -eq 0) { throw (RU $R_csv_empty) }
  # Common English CSV headers used by Chrome, Edge, Firefox and many managers.
  $ph=Find-CsvColumn $rows @("password","passwd","pass","pwd")
  if (-not $ph) { throw (RU $R_no_pass_col) }
  $uh=Find-CsvColumn $rows @("username","user","login","email","emailaddress")
  $nh=Find-CsvColumn $rows @("name","title","site","website","service","label")
  $rh=Find-CsvColumn $rows @("url","uri","website","login_uri")
  foreach ($row in $rows) {
    $pass=[string]$row.PSObject.Properties[$ph].Value; $user=""; $name=""; $uri=""
    if ($uh) { $user=[string]$row.PSObject.Properties[$uh].Value }
    if ($nh) { $name=[string]$row.PSObject.Properties[$nh].Value }
    if ($rh) { $uri=[string]$row.PSObject.Properties[$rh].Value }
    Add-Account $Map $pass $name $user $uri
  }
}

$files=@(Get-ChildItem -Path $Folder -File | Where-Object { ($_.Extension -ieq ".json" -or $_.Extension -ieq ".csv") -and $_.Name -notlike "simpler_login_search_result*" })
Clear-Host
Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "         SIMPLER LOGIN SEARCH" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
if ($files.Count -eq 0) { Write-Host (RU $R_no_files) -ForegroundColor Red; Write-Host ""; Read-Host (RU $R_exit); exit }
Write-Host (RU $R_files) -ForegroundColor Yellow
Write-Host ""
for ($i=0;$i -lt $files.Count;$i++) { Write-Host ("  [{0}] {1}" -f ($i+1),$files[$i].Name) }
Write-Host ""
Write-Host ("  [0] " + (RU $R_newest)) -ForegroundColor DarkGray
Write-Host ""
$choice=Read-Host (RU $R_prompt)
if ([string]::IsNullOrWhiteSpace($choice) -or $choice -eq "0") { $selected=$files|Sort-Object LastWriteTime -Descending|Select-Object -First 1 }
else {
  $n=0
  if (-not [int]::TryParse($choice,[ref]$n)) { Write-Host (RU $R_bad) -ForegroundColor Red; Read-Host (RU $R_exit); exit }
  $idx=$n-1
  if ($idx -lt 0 -or $idx -ge $files.Count) { Write-Host (RU $R_bad) -ForegroundColor Red; Read-Host (RU $R_exit); exit }
  $selected=$files[$idx]
}

Clear-Host
Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "         SIMPLER LOGIN SEARCH" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host ((RU $R_selected) -f $selected.Name) -ForegroundColor Green
Write-Host ""
Write-Host (RU $R_loading) -ForegroundColor Yellow
$Passwords=@{}
try { if ($selected.Extension -ieq ".json") { Import-JsonExport $selected.FullName $Passwords } else { Import-CsvExport $selected.FullName $Passwords } }
catch { Write-Host ""; Write-Host ((RU $R_read_error) -f $_.Exception.Message) -ForegroundColor Red; Write-Host ""; Read-Host (RU $R_exit); exit }
Write-Host ((RU $R_unique) -f $Passwords.Count) -ForegroundColor Cyan
Write-Host ""; Write-Host (RU $R_checking) -ForegroundColor Yellow

@(
  (RU $R_title),
  (RU $R_warning),
  "",
  (RU $R_search),
  "https://haveibeenpwned.com/Passwords",
  ((RU $R_date) -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss")),
  ((RU $R_file) -f $selected.Name),
  "",
  "========================================",
  (RU $R_results),
  "========================================",
  ""
) | Set-Content -Path $ResultFile -Encoding UTF8

$foundAny=$false; $foundPasswords=0; $checked=0; $errors=0
foreach ($Password in $Passwords.Keys) {
  $checked++
  Write-Progress -Activity (RU $R_checking) -Status "$checked / $($Passwords.Count)" -PercentComplete (($checked/$Passwords.Count)*100)
  $bytes=[Text.Encoding]::UTF8.GetBytes($Password)
  $sha1=[Security.Cryptography.SHA1]::Create()
  $hb=$sha1.ComputeHash($bytes)
  $hash=-join ($hb|ForEach-Object { $_.ToString("X2") })
  $prefix=$hash.Substring(0,5); $suffix=$hash.Substring(5)
  try {
    $response=Invoke-RestMethod -Uri ("https://api.pwnedpasswords.com/range/"+$prefix) -Headers @{"Add-Padding"="true"} -Method Get -ErrorAction Stop
    foreach ($line in ($response -split "`r?`n")) {
      if ([string]::IsNullOrWhiteSpace($line)) { continue }
      $parts=$line -split ":"; if ($parts.Count -ne 2) { continue }
      if ($parts[0].Trim().ToUpperInvariant() -eq $suffix) {
        $foundAny=$true; $foundPasswords++
        Add-Content $ResultFile -Encoding UTF8 -Value "========================================"
        Add-Content $ResultFile -Encoding UTF8 -Value ((RU $R_comp) -f $foundPasswords)
        Add-Content $ResultFile -Encoding UTF8 -Value "========================================"
        Add-Content $ResultFile -Encoding UTF8 -Value ((RU $R_password) -f $Password)
        Add-Content $ResultFile -Encoding UTF8 -Value ((RU $R_count) -f $parts[1].Trim())
        Add-Content $ResultFile -Encoding UTF8 -Value ""
        Add-Content $ResultFile -Encoding UTF8 -Value (RU $R_used)
        foreach ($a in $Passwords[$Password]) {
          Add-Content $ResultFile -Encoding UTF8 -Value "----------------------------------------"
          Add-Content $ResultFile -Encoding UTF8 -Value ((RU $R_site) -f $a.Name)
          Add-Content $ResultFile -Encoding UTF8 -Value ((RU $R_login) -f $a.Username)
          Add-Content $ResultFile -Encoding UTF8 -Value ((RU $R_url) -f $a.URI)
        }
        Add-Content $ResultFile -Encoding UTF8 -Value ""
        Add-Content $ResultFile -Encoding UTF8 -Value ""
        Write-Host (RU $R_found_console) -ForegroundColor Red
        break
      }
    }
  } catch { $errors++ }
}
Write-Progress -Activity (RU $R_checking) -Completed
Add-Content $ResultFile -Encoding UTF8 -Value "========================================"
Add-Content $ResultFile -Encoding UTF8 -Value (RU $R_summary)
Add-Content $ResultFile -Encoding UTF8 -Value "========================================"
Add-Content $ResultFile -Encoding UTF8 -Value ((RU $R_checked) -f $Passwords.Count)
Add-Content $ResultFile -Encoding UTF8 -Value ((RU $R_found) -f $foundPasswords)
Add-Content $ResultFile -Encoding UTF8 -Value ((RU $R_errors) -f $errors)

Clear-Host
Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "         SIMPLER LOGIN SEARCH" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host ((RU $R_checked) -f $Passwords.Count)
if ($foundAny) { Write-Host ((RU $R_found) -f $foundPasswords) -ForegroundColor Red } else { Write-Host (RU $R_none) -ForegroundColor Green }
if ($errors -gt 0) { Write-Host ((RU $R_errors) -f $errors) -ForegroundColor Yellow }
Write-Host ""
Write-Host ((RU $R_saved) -f $ResultFile) -ForegroundColor Green
Write-Host ""
Write-Host (RU $R_delete) -ForegroundColor Yellow
Write-Host ""
Read-Host (RU $R_exit)
