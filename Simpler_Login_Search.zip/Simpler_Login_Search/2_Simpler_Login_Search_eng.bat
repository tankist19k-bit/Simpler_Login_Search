@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -NoLogo -File "%~dp02_Simpler_Login_Search_eng.ps1"
if errorlevel 1 (
    echo.
    echo PowerShell returned an error.
    echo.
)
pause
endlocal
